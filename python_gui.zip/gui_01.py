from PyQt5.QtWidgets import QWidget, QApplication, QLabel, QVBoxLayout, QPushButton, QToolTip, QMainWindow, QAction, qApp, QDesktopWidget
from PyQt5.QtCore import Qt, QDateTime, QDate, QTime
from PyQt5 import QtGui
from PyQt5.QtGui import QIcon, QFont
from PyQt5.QtCore import QCoreApplication
import sys

# now = QDate.currentDate()
# print(now.toString())
# print(now.toString("d.M.yy"))
# print(now.toString("dd.MM.yyyy"))
# print(now.toString("ddd.MMMM.yyyy"))
# print(now.toString(Qt.ISODate))
# print(now.toString(Qt.DefaultLocaleLongDate))
# print("______________________________________")

# time = QTime.currentTime()
# print(time.toString())
# print(time.toString("h.m.s"))
# print(time.toString("hh.mm.ss"))
# print(time.toString("hh.mm.ss.zzz"))
# print(time.toString(Qt.DefaultLocaleLongDate))
# print(time.toString(Qt.DefaultLocaleShortDate))
# print("______________________________________")

# datetime = QDateTime.currentDateTime()
# print(datetime.toString())

class MyApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.date = QDate.currentDate()
        self.initUI()
        
    def initUI(self):
        # QToolTip.setFont(QFont("SansSerif", 10)) # 툴팁에 사용될 폰트 설정
        # self.setToolTip("This is a <b>QWidget</b> widget") # 툴팁에 표시될 텍스트
        
        # btn = QPushButton("Button", self) # 푸쉬 버튼 생성
        # btn.setToolTip("This is a <b>QPushButton</b> widget")
        # btn.move(50, 50) # 버튼 위치
        # btn.resize(btn.sizeHint()) # 버튼 크기
        
        # btn = QPushButton("Quit", self) # Quit라는 푸쉬 버튼 생성
        # btn.move(50, 50) # 버튼 위치
        # btn.resize(btn.sizeHint()) # 버튼 크기
        # btn.clicked.connect(QCoreApplication.instance().quit)
        
        # self.statusBar().showMessage("Ready")
        
        # ______________________________________________________
        # exitAction = QAction("Exit", self) # 
        # exitAction.setShortcut("ctrl+Q") # 단축키 설정
        # exitAction.setStatusTip("Exit application") # 
        
        # exitAction.triggered.connect(qApp.quit) # 창 닫기
        
        # self.statusBar()
        
        # menubar = self.menuBar()
        # menubar.setNativeMenuBar(False)
        # filemenu = menubar.addMenu("&File")
        # filemenu.addAction(exitAction)
        # ______________________________________________________
        
        self.statusBar().showMessage(self.date.toString(Qt.DefaultLocaleLongDate))
        
        self.setWindowTitle("gui") # 창의 제목
        self.setWindowIcon(QIcon(r"C:\Users\Blackstorm_plecios\Desktop\python_gui\web.png")) # 창의 아이콘 설정
        # self.setGeometry(300, 300, 300, 200) # (x(창의 위치), y(창의 위치), aw(창의 너비), ah(창의 높이))
        # self.move(300, 300) # 창의 위치
        self.resize(500, 350) # 창의 크기
        self.center() # 창이 화면 가운데에 위치
        self.show() # 창 출력
        
    def center(self):
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center() # 모니터 화면의 가운데 위치 파악
        qr.moveCenter(cp) # 창의 직사각형 위치를 화면 중심으로 이동
        self.move(qr.topLeft())
        
if __name__ == '__main__':
    app = QApplication(sys.argv) # 객체 생성
    ex = MyApp()
    sys.exit(app.exec_())