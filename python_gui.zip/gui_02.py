from PyQt5.QtWidgets import (QWidget, QApplication, QLabel, QVBoxLayout, QPushButton, QToolTip, QMainWindow, QAction, qApp, QDesktopWidget, 
QHBoxLayout, QGridLayout, QTextEdit, QLineEdit, QCheckBox, QRadioButton, QComboBox, QProgressBar, QSlider, QDial, QGroupBox, QMenu, QTabWidget, QCalendarWidget, QSpinBox, QDoubleSpinBox, QDateEdit, QTimeEdit, QDateTimeEdit, QInputDialog, QFrame, QColorDialog,
QSizePolicy, QFontDialog, QMessageBox, QLCDNumber)
from PyQt5.QtCore import Qt, QDateTime, QDate, QTime
from PyQt5 import QtGui
from PyQt5.QtGui import QIcon, QFont, QPixmap, QColor
from PyQt5.QtCore import QCoreApplication, QBasicTimer, Qt
from PyQt5.QtWidgets import *
import sys

class MyApp(QWidget):
    
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        lcd = QLCDNumber(self)
        dial = QDial(self)
        btn1 = QPushButton("big", self)
        btn2 = QPushButton("small", self)
        
        hbox = QHBoxLayout()
        hbox.addWidget(btn1)
        hbox.addWidget(btn2)
        
        vbox = QVBoxLayout()
        vbox.addWidget(lcd)
        vbox.addWidget(dial)
        vbox.addLayout(hbox)
        self.setLayout(vbox)
        
        dial.valueChanged.connect(lcd.display)
        btn1.clicked.connect(self.resizeBig)
        btn2.clicked.connect(self.resizeSmall)
        
        self.setWindowTitle("Signal and Slot")
        self.setGeometry(200, 200, 200, 250)
        # self.move(300, 300)
        self.show()
        
    def resizeBig(self):
        self.resize(400, 500)
        
    def resizeSmall(self):
        self.resize(200, 250)

if __name__ == '__main__':
    app = QApplication(sys.argv) # 객체 생성
    ex = MyApp()
    sys.exit(app.exec_())