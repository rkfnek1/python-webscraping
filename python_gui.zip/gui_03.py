from PyQt5.QtWidgets import (QWidget, QApplication, QLabel, QVBoxLayout, QPushButton, QToolTip, QMainWindow, QAction, qApp, QDesktopWidget, 
QHBoxLayout, QGridLayout, QTextEdit, QLineEdit, QCheckBox, QRadioButton, QComboBox, QProgressBar, QSlider, QDial, QGroupBox, QMenu, QTabWidget, QCalendarWidget, QSpinBox, QDoubleSpinBox, QDateEdit, QTimeEdit, QDateTimeEdit, QInputDialog, QFrame, QColorDialog,
QSizePolicy, QFontDialog, QMessageBox, QLCDNumber)
from PyQt5.QtCore import Qt, QDateTime, QDate, QTime, QCoreApplication, QBasicTimer, pyqtSignal, QObject
from PyQt5 import QtGui
from PyQt5.QtGui import QIcon, QFont, QPixmap, QColor
from PyQt5.QtWidgets import *
import sys
import requests
import openpyxl
from bs4 import BeautifulSoup
import os

class MyApp(QWidget):
    
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        label = QLabel("URL 입력", self) # URL 입력 라벨 출력
        label.move(40, 55) # 라벨 출력 위치 설정
        
        label_1 = QLabel("SD카드 URL 입력", self) # URL 입력 라벨 출력
        label_1.move(30, 25) # 라벨 출력 위치 설정
        
        self.qle = QLineEdit(self) # 한줄 문자열 위젯 생성
        self.qle.move(100, 50) # 위젯 출력 위치 설정
        self.qle.setText("")
        
        self.qle_1 = QLineEdit(self) # 한줄 문자열 위젯 생성
        self.qle_1.move(135, 20) # 위젯 출력 위치 설정
        self.qle_1.setText("")
        
        btn1 = QPushButton(self) # 푸쉬 버튼 위젯 생성
        btn1.move(280, 50) # 버튼 출력 위치 설정
        btn1.setText("정보 저장") # 버튼에 "오픈 저장" 텍스트 노출
        btn1.clicked.connect(self.btn1_clicked) # 버튼이 눌리면 btn1_clicked 함수 실행
        
        btn2 = QPushButton(self) # 푸쉬 버튼 위젯 생성
        btn2.move(380, 50) # 버튼 출력 위치 설정
        btn2.setText("내용 지우기") # 버튼에 "내용 지우기" 텍스트 노출
        btn2.clicked.connect(self.btn2_clicked) # 버튼이 눌리면 btn2_clicked 함수 실행
        
        btn3 = QPushButton(self) # 푸쉬 버튼 위젯 생성
        btn3.move(480, 50) # 버튼 출력 위치 설정
        btn3.setText("엑셀 오픈") # 버튼에 "오픈 저장" 텍스트 노출
        btn3.clicked.connect(self.btn3_clicked) # 버튼이 눌리면 btn1_clicked 함수 실행
        
        btn3 = QPushButton(self) # 푸쉬 버튼 위젯 생성
        btn3.move(480, 50) # 버튼 출력 위치 설정
        btn3.setText("엑셀 오픈") # 버튼에 "오픈 저장" 텍스트 노출
        btn3.clicked.connect(self.btn3_clicked) # 버튼이 눌리면 btn1_clicked 함수 실행
        
        btn4 = QPushButton(self) # 푸쉬 버튼 위젯 생성
        btn4.move(290, 18) # 버튼 출력 위치 설정
        btn4.setText("SD 정보 저장") # 버튼에 "오픈 저장" 텍스트 노출
        btn4.clicked.connect(self.btn4_clicked) # 버튼이 눌리면 btn1_clicked 함수 실행
        
        self.text_edit = QTextEdit(self) # 편집기 위젯 생성
        self.text_edit.setGeometry(50, 100, 500, 200) # 편집기 위젯 위치 및 크기 설정
        self.text_edit.setEnabled(False) 
        
        self.setWindowTitle("deviec") # 윈도우창 타이틀 이름
        self.setGeometry(500, 500, 600, 400) # 윈도우창이 출력되는 위치 및 크기 설정
        self.show() # 윈도우창 보여주기
    
    # def onChanged(self, text):
    #     self.lbl = QLabel(self)
    #     # self.lbl.setTextFormat(Qt.plainText)
    #     self.lbl.setText(text)
    #     self.lbl.adjustSize()
        
    def btn1_clicked(self):
        inp = self.qle.text() # 한줄 문자열 위젯에 등록된 글씨를 텍스트로 저장해 inp 변수로 지정
        
        # wb = openpyxl.load_workbook(r'C:\Users\Blackstorm_plecios\Desktop\python_gui\디바이스.xlsx') # 만들어져 있는 엑셀 오픈
        wb = openpyxl.load_workbook('디바이스.xlsx') # 만들어져 있는 엑셀 오픈
        
        sheet = wb.active # 현재 Active Sheet 얻기
        
        # url = "https://www.phonearena.com/phones/Google-Pixel-6_id11732" # url 정보 입력 (새로운 디아비스의 url을 여기다 입력)
        
        res = requests.get(inp) # res 변수에 inp 변수 담기
        res.raise_for_status # 접속이 문제 없는지 확인
        soup = BeautifulSoup(res.text, "lxml") # BeautifulSoup 변수 생성

        Phone = soup.select_one('body > article > div.layout__page_breadcrumbs > ul > li.active > span').text
        Phone2 = Phone.rstrip() # 뒤에 공백 제거

        Processor = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(2) > td').text
        Processor2 = Processor.rstrip() # 뒤에 공백 제거

        GPU = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(3) > td').text
        GPU2 = GPU.rstrip() # 뒤에 공백 제거

        System_chip = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(1) > td').text
        System_chip2 = System_chip.rstrip() # 뒤에 공백 제거

        RAM = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(4) > td').text
        RAM2 = RAM.rstrip() # 뒤에 공백 제거

        Internal_storage = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(5) > td').text
        Internal_storage2 = Internal_storage.rstrip() # 뒤에 공백 제거

        Device_type = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(6) > td').text
        Device_type2 = Device_type.rstrip() # 뒤에 공백 제거\
        
        OS = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(7) > td').text
        OS2 = OS.rstrip() # 뒤에 공백 제거

        Size = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(1) > table > tbody > tr:nth-child(1) > td').text
        Size2 = Size.rstrip() # 뒤에 공백 제거

        Resolution = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(1) > table > tbody > tr:nth-child(2) > td').text
        Resolution2 = Resolution.rstrip() # 뒤에 공백 제거
        
        Released = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_quickSpecs > section.phone__section.phone__section_widget_quickSpecs > div > div > a.widgetQuickSpecs__link.calendar > div.widgetQuickSpecs__title > p').text
        Released2 = Released.rstrip() # 뒤에 공백 제거
        
        sheet.append([Phone2, System_chip2, Processor2, GPU2, RAM2, Internal_storage2, Device_type2, OS2, Size2, Resolution2, Released2]) # 변수 이름 입력으로 디바이스 정보 입력
        
        # wb.save(r'C:\Users\Blackstorm_plecios\Desktop\python_gui\디바이스.xlsx') # 엑셀 파일 세이브
        wb.save('디바이스.xlsx') # 엑셀 파일 세이브
        wb.close() # 엑셀 파일 닫기
        
        self.text_edit.append(Phone2 + System_chip2 + Processor2 + GPU2 + RAM2 + Internal_storage2 + Device_type2 + OS2 + Size2 + Resolution2 + Released2) # 편집기 위젯에 수집한 내용 출력
        
        # filepath = r'C:\Users\Blackstorm_plecios\Desktop\python_gui\디바이스.xlsx'

    def btn2_clicked(self):
        self.text_edit.clear() # 편집기 위젯에 내용 삭제
        
    def btn3_clicked(self):
        filepath = '디바이스.xlsx' # 오픈할 파일을 지정
        os.startfile(filepath) # 파일 오픈
        
    def btn4_clicked(self):
        inp = self.qle_1.text() # 한줄 문자열 위젯에 등록된 글씨를 텍스트로 저장해 inp 변수로 지정
        
        # wb = openpyxl.load_workbook(r'C:\Users\Blackstorm_plecios\Desktop\python_gui\디바이스.xlsx') # 만들어져 있는 엑셀 오픈
        wb = openpyxl.load_workbook('디바이스.xlsx') # 만들어져 있는 엑셀 오픈
        
        sheet = wb.active # 현재 Active Sheet 얻기
        
        # url = "https://www.phonearena.com/phones/Google-Pixel-6_id11732" # url 정보 입력 (새로운 디아비스의 url을 여기다 입력)
        
        res = requests.get(inp) # res 변수에 inp 변수 담기
        res.raise_for_status # 접속이 문제 없는지 확인
        soup = BeautifulSoup(res.text, "lxml") # BeautifulSoup 변수 생성

        Phone = soup.select_one('body > article > div.layout__page_breadcrumbs > ul > li.active > span').text
        Phone2 = Phone.rstrip() # 뒤에 공백 제거

        Processor = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(2) > td').text
        Processor2 = Processor.rstrip() # 뒤에 공백 제거

        GPU = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(3) > td').text
        GPU2 = GPU.rstrip() # 뒤에 공백 제거

        System_chip = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(1) > td').text
        System_chip2 = System_chip.rstrip() # 뒤에 공백 제거

        RAM = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(4) > td').text
        RAM2 = RAM.rstrip() # 뒤에 공백 제거

        Internal_storage = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(5) > td').text
        Internal_storage2 = Internal_storage.rstrip() # 뒤에 공백 제거
        
        Storage_expansion = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(6) > td').text
        Storage_expansion2 = Storage_expansion.rstrip()
        
        Device_type = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(7) > td').text
        Device_type2 = Device_type.rstrip() # 뒤에 공백 제거\
        
        OS = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(3) > table > tbody > tr:nth-child(8) > td').text
        OS2 = OS.rstrip() # 뒤에 공백 제거

        Size = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(1) > table > tbody > tr:nth-child(1) > td').text
        Size2 = Size.rstrip() # 뒤에 공백 제거

        Resolution = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_specs > section > div.widgetSpecs > section:nth-child(1) > table > tbody > tr:nth-child(2) > td').text
        Resolution2 = Resolution.rstrip() # 뒤에 공백 제거
        
        Released = soup.select_one('body > article > div.layout__page_main > section.page__section.page__section_quickSpecs > section.phone__section.phone__section_widget_quickSpecs > div > div > a.widgetQuickSpecs__link.calendar > div.widgetQuickSpecs__title > p').text
        Released2 = Released.rstrip() # 뒤에 공백 제거
        
        sheet.append([Phone2, System_chip2, Processor2, GPU2, RAM2, Internal_storage2, Device_type2, OS2, Size2, Resolution2, Released2, Storage_expansion2]) # 변수 이름 입력으로 디바이스 정보 입력
        
        # wb.save(r'C:\Users\Blackstorm_plecios\Desktop\python_gui\디바이스.xlsx') # 엑셀 파일 세이브
        wb.save('디바이스.xlsx') # 엑셀 파일 세이브
        wb.close() # 엑셀 파일 닫기
        
        self.text_edit.append(Phone2 + System_chip2 + Processor2 + GPU2 + RAM2 + Internal_storage2 + Storage_expansion2 + Device_type2 + OS2 + Size2 + Resolution2 + Released2) # 편집기 위젯에 수집한 내용 출력

if __name__ == '__main__':
    app = QApplication(sys.argv) # 객체 생성
    ex = MyApp()
    sys.exit(app.exec_())