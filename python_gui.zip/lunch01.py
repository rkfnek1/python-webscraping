from msilib.schema import ComboBox
from PyQt5.QtWidgets import (QWidget, QApplication, QLabel, QVBoxLayout, QPushButton, QToolTip, QMainWindow, QAction, qApp, QDesktopWidget, 
QHBoxLayout, QGridLayout, QTextEdit, QLineEdit, QCheckBox, QRadioButton, QComboBox, QProgressBar, QSlider, QDial, QGroupBox, QMenu, QTabWidget, QCalendarWidget, QSpinBox, QDoubleSpinBox, QDateEdit, QTimeEdit, QDateTimeEdit, QInputDialog, QFrame, QColorDialog,
QSizePolicy, QFontDialog, QMessageBox, QLCDNumber)
from PyQt5.QtCore import Qt, QDateTime, QDate, QTime, QCoreApplication, QBasicTimer, pyqtSignal, QObject
from PyQt5 import QtGui
from PyQt5.QtGui import QIcon, QFont, QPixmap, QColor
from PyQt5.QtWidgets import *
import sys
import random
import sys

class MyApp(QWidget):
    
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        label = QLabel("식당 리스트", self) # URL 입력 라벨 출력
        label.move(30, 55) # 라벨 출력 위치 설정
        
        # self.qle = QLineEdit(self) # 한줄 문자열 위젯 생성
        # self.qle.move(100, 50) # 위젯 출력 위치 설정
        # self.qle.setText("")
        self.cb = QComboBox(self)
        self.cb.addItem("발해 양꼬치")
        self.cb.addItem("전티마이 베트남 쌀국수")
        self.cb.addItem("미가라멘")
        self.cb.addItem("현대옥")
        self.cb.addItem("버거 스캔들")
        self.cb.addItem("청담동 마녀김밥")
        self.cb.addItem("텬고")
        self.cb.addItem("그리너")
        self.cb.addItem("비아김밥")
        self.cb.addItem("버텍스 미국식 덮밥")
        self.cb.addItem("육대장")
        self.cb.addItem("은행골")
        self.cb.addItem("킹스부대찌개")
        self.cb.addItem("슬로우캘리")
        self.cb.move(100, 50)

        btn1 = QPushButton(self) # 푸쉬 버튼 위젯 생성
        btn1.move(280, 50) # 버튼 출력 위치 설정
        btn1.setText("클릭!") # 버튼에 "오픈 저장" 텍스트 노출
        btn1.clicked.connect(self.btn1_clicked) # 버튼이 눌리면 btn1_clicked 함수 실행
        
        btn2 = QPushButton(self) # 푸쉬 버튼 위젯 생성
        btn2.move(380, 50) # 버튼 출력 위치 설정
        btn2.setText("내용 지우기") # 버튼에 "내용 지우기" 텍스트 노출
        btn2.clicked.connect(self.btn2_clicked) # 버튼이 눌리면 btn2_clicked 함수 실행
        
        self.text_edit = QTextEdit(self) # 편집기 위젯 생성
        self.text_edit.setGeometry(50, 100, 500, 200) # 편집기 위젯 위치 및 크기 설정
        self.text_edit.setEnabled(False) 
        
        self.setWindowTitle("lunch") # 윈도우창 타이틀 이름
        self.setGeometry(500, 500, 600, 400) # 윈도우창이 출력되는 위치 및 크기 설정
        self.show() # 윈도우창 보여주기
        
    def btn1_clicked(self):
        rtl = self.cb.currentText() # 한줄 문자열 위젯에 등록된 글씨를 텍스트로 저장해 inp 변수로 지정

        bh = "발해 양꼬치" # 가게 이름 변수 생성
        bh_1 = ["짜장면", "짬뽕", "새우볶음밥", "마파두부덮밥"] # 메뉴 리스트 새성
        
        # jg = "찌개마을" 
        # jg_1 = ["김치찌개", "된장찌개"]
        
        # Chinese_food = "셰프 짬뽕"
        # Chinese_food_1 = ["짬뽕", "짜장면", "간짜장", "볶음밥", "짜장밥", "짬뽕밥"]
        
        rice_noodles = "전티마이 베트남 쌀국수"
        rice_noodles_1 = ["소고기쌀국수", "볶음밥"]
        
        ramen = "미가라멘"
        ramen_1 = ["돈코츠라멘", "미소라멘", "소유라멘", "시오버터라멘", "나가사키짬뽕", "얼큰짬뽕", "치킨가라아게동", "가츠동", "에비동", "차슈동"]
        
        hd = "현대옥"
        hd_1 = ["전주끓이는식콩나물국밥", "전주남부시장식 콩나물국밥", "얼큰돼지국밥", "황태콩나물국밥", "오색나물콩나물국밥", "순한두부찌개", "현대옥순대국밥", "현대옥순한두부찌개", "현대옥콩나물밥", "전주비빔밥", "현대옥스테이크"]
        
        burgerscandal = "버거 스캔들"
        burgerscandal_1 = ["스캔들버거 세트", "피쉬앤치즈버거 세트", "레전드치킨버거 세트", "아메리칸 치즈버거 세트"]
        
        kimbap = "청담동 마녀김밥"
        kimbap_1 = ["마녀김밥", "야채김밥", "계란마녀김밥", "고추김밥", "멸치김밥", "참치김밥", "핫도그김밥", "묵은지김밥", "묵참김밥", "마녀떡볶이", "마녀쫄면", "마녀라면", "묵은지 라면"]
        
        Tengo = "텬고"
        Tengo_1 = ["텬고 국물 떡볶이", "텬고 치브 떡볶이", "텬고 치즈라볶이", "텬고 라볶이"]
        
        Greener = "그리너"
        Greener_1 = "식대 가격 초과로 메뉴 추천 제외"
        
        kimbap2 = "비아김밥"
        kimbap2_1 = ["일반 라면", "표고라면", "미역 너구리", "야채김밥", "참치김밥", "치즈김밥", "김치김밥", "야땡김밥(야채+땡초)", " 참땡(참치+땡초)", " 김땡(김치+땡초)", "멸땡(멸치+땡초)", " 왕계란김밥", "크래미김밥", "돈가스김밥", "왕새우김밥", "스팸김밥", "고추장진미김밥", "간장진미김밥", "소고기김밥", "계란김치김밥", "참치치즈김밥", "참치김치김밥", "고추장진미치즈김밥", " 고추장진미새우김밥", "고기없는채소김밥(키토)", "채소김밥고기많이(키토)", "왕계란키토"]
        
        vertex = "버텍스 미국식 덮밥"
        vertex_1 = "식대 가격 초과로 메뉴 추천 제외"
        
        yuggyejang = "육대장"
        yuggyejang_1 = "식대 가격 초과로 메뉴 추천 제외"
        
        eunhaeng_gol = "은행골"
        eunhaeng_gol_1 = "식대 가격 초과로 메뉴 추천 제외"
        
        budaejjigae = "킹스부대찌개"
        budaejjigae_1 = "식대 가격 초과로 메뉴 추천 제외"
        
        SlowCali = "슬로우캘리"
        SlowCali_1 = "식대 가격 초과로 메뉴 추천 제외"
        
        # Gyodong = "교동짬뽕"
        # Gyodong_1 = []
        
        # bonjug = "본죽&비빔밥 카페"
        # bonjug_1 = []
        
        # Subway = "서브웨이"
        # Subway_1 = []
        
        sundae = "83순대국"
        sundae_1 = "순대국"
        
        # Burger_King = "버거킹"
        # Burger_King_1 = []
        
        if rtl == bh: # 변수 c에 지정된 가게와 변수 bh에 생성된 가게 이름 비교
            random.shuffle(bh_1) # 메뉴 리스트 섞기
            bh_2 = random.choice(bh_1) # 섞인 lunch 리스트에서 메뉴 선택
            bh_3 = random.choice(bh_1) # 섞인 lunch 리스트에서 메뉴 선택
            n = bh_2 # 선택된 메뉴 변수로 지정
            s = bh_3 # 선택된 메뉴 변수로 지정
        # elif c == Chinese_food:
        #     random.shuffle(Chinese_food_1) # 메뉴 리스트 섞기
        #     Chinese_food_2 = random.choice(Chinese_food_1)
        #     Chinese_food_3 = random.choice(Chinese_food_1)
        #     n = Chinese_food_2
        #     s = Chinese_food_3
        elif rtl == ramen:
            random.shuffle(ramen_1) # 메뉴 리스트 섞기
            ramen_2 = random.choice(ramen_1)
            ramen_3 = random.choice(ramen_1)
            n = ramen_2
            s = ramen_3
        elif rtl == rice_noodles:
            random.shuffle(rice_noodles_1) # 메뉴 리스트 섞기
            rice_noodles_2 = random.choice(rice_noodles_1)
            rice_noodles_3 = random.choice(rice_noodles_1)
            n = rice_noodles_2
            s = rice_noodles_3
        elif rtl == hd:
            random.shuffle(hd_1)
            hd_2 = random.choice(hd_1)
            hd_3 = random.choice(hd_1)
            n = hd_2
            s = hd_3
        elif rtl == burgerscandal:
            random.shuffle(burgerscandal_1)
            burgerscandal_2 = random.choice(burgerscandal_1)
            burgerscandal_3 = random.choice(burgerscandal_1)
            n = burgerscandal_2
            s = burgerscandal_3
        elif rtl == kimbap:
            random.shuffle(kimbap_1)
            kimbap_2 = random.choice(kimbap_1)
            kimbap_3 = random.choice(kimbap_1)
            n = kimbap_2
            s = kimbap_3
        elif rtl == Tengo:
            random.shuffle(Tengo_1)
            Tengo_2 = random.choice(Tengo_1)
            Tengo_3 = random.choice(Tengo_1)
            n = Tengo_2
            s = Tengo_3
        elif rtl == Greener:
            n = Greener_1
            s = Greener_1
        elif rtl == sundae:
            random.shuffle(sundae_1)
            sundae_2 = random.choice(sundae_1)
            sundae_3 = random.choice(sundae_1)
            n = sundae_2
            s = sundae_3
        elif rtl == kimbap2:
            random.shuffle(kimbap2_1)
            kimbap2_2 = random.choice(kimbap2_1)
            kimbap2_3 = random.choice(kimbap2_1)
            n = kimbap2_2
            s = kimbap2_3
        elif rtl == vertex:
            n = vertex_1
            s = vertex_1
        elif rtl == yuggyejang:
            n = yuggyejang_1
            s = yuggyejang_1
        elif rtl == eunhaeng_gol:
            n = eunhaeng_gol_1
            s = eunhaeng_gol_1
        elif rtl == budaejjigae:
            n = budaejjigae_1
            s = budaejjigae_1
        elif rtl == SlowCali:
            n = SlowCali_1
            s = SlowCali_1
            
        self.text_edit.append(f"추천 메뉴\n팀장님 : {n}\n사원 : {s}") # 편집기 위젯에 수집한 내용 출력
        
    def btn2_clicked(self):
        self.text_edit.clear() # 편집기 위젯에 내용 삭제

if __name__ == '__main__':
    app = QApplication(sys.argv) # 객체 생성
    ex = MyApp()
    sys.exit(app.exec_())