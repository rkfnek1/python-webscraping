from msilib.schema import CheckBox
from turtle import isvisible
from PyQt5.QtWidgets import (QWidget, QApplication, QLabel, QVBoxLayout, QPushButton, QToolTip, QMainWindow, QAction, qApp, QDesktopWidget, 
QHBoxLayout, QGridLayout, QTextEdit, QLineEdit, QCheckBox, QRadioButton, QComboBox, QProgressBar, QSlider, QDial, QGroupBox, QMenu, QTabWidget, QCalendarWidget, QSpinBox, QDoubleSpinBox, QDateEdit, QTimeEdit, QDateTimeEdit, QInputDialog, QFrame, QColorDialog,
QSizePolicy, QFontDialog, QFileDialog)
from PyQt5.QtCore import Qt, QDateTime, QDate, QTime
from PyQt5 import QtGui
from PyQt5.QtGui import QIcon, QFont, QPixmap, QColor
from PyQt5.QtCore import QCoreApplication, QBasicTimer, Qt
from PyQt5.QtWidgets import *
import sys

class MyApp(QMainWindow):
    
    def __init__(self):
        super().__init__()
        self.initUI()
        
    def initUI(self):
        self.textedit = QTextEdit()
        self.setCentralWidget(self.textedit)
        self.statusBar()
        
        openFile = QAction(QIcon("open.png"), "Open", self)
        openFile.setShortcut("ctrl+o")
        openFile.setStatusTip("Open New File")
        openFile.triggered.connect(self.showDialog)
        
        menubar = self.menuBar()
        menubar.setNativeMenuBar(False)
        fileMenu = menubar.addMenu('&File')
        fileMenu.addAction(openFile)
        
        self.setWindowTitle('File Dialog')
        self.setGeometry(300, 300, 300, 200)
        # self.move(300, 300)
        self.show()
        
    def showDialog(self):
        fname = QFileDialog.getOpenFileName(self, "Open file", "./")
        if fname[0]:
            f = open(fname[0], "r")
            
            with f:
                data = f.read()
                self.textedit.setText(data)

if __name__ == '__main__':
    app = QApplication(sys.argv) # 객체 생성
    ex = MyApp()
    sys.exit(app.exec_())